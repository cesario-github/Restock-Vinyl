"""
Restock-Checker fuer die GTA 6: The Album - Limited Edition Vinyl
==================================================================

Was das Skript tut:
1. Ruft die Produktseite ab.
2. Prueft, ob Text wie "sold out" / "ausverkauft" auf der Seite steht.
3. Wenn der Status von "ausverkauft" auf "verfuegbar" wechselt,
   schickt es sofort eine Nachricht an Discord (und optional Telegram).
4. Merkt sich den letzten Status in last_state.txt, damit nicht bei
   jedem Lauf erneut Alarm geschlagen wird.

WICHTIGER HINWEIS (bitte lesen):
Manche Onlineshops laden den Lagerbestand per JavaScript NACH dem ersten
Laden der Seite nach (z.B. React/Next.js-Shops). Ein einfacher
requests.get() sieht dann u.U. nicht den echten "verfuegbar"-Status,
sondern nur das leere Grundgeruest der Seite. Falls der Checker nach dem
Testlauf (siehe README) keine zuverlaessigen Ergebnisse liefert, ist das
der wahrscheinlichste Grund - dann braucht es einen "echten" Browser
(z.B. Playwright) statt einer einfachen Textabfrage.
"""

import os
import sys
import requests

# ==========================================================
# KONFIGURATION - HIER ANPASSEN
# ==========================================================

# Trage hier die genaue Produktseite der Limited Edition ein.
# (Den Link am besten direkt aus der Adresszeile kopieren, wenn du
# die Produktseite selbst besuchst - der Kurzlink aus dem Rockstar-Tweet
# reicht nicht, das ist nur eine Weiterleitung.)
PRODUCT_URL = "https://PASTE-DIE-ECHTE-PRODUKTSEITE-HIER-EIN.example.com"

# Textbausteine, die auf "nicht verfuegbar" hindeuten (klein geschrieben).
OUT_OF_STOCK_PATTERNS = [
    "sold out",
    "ausverkauft",
    "out of stock",
    "nicht verfügbar",
    "nicht verfuegbar",
    "notify me",  # viele Shops zeigen das statt "add to cart", wenn leer
]

STATE_FILE = "last_state.txt"

# Secrets kommen aus Umgebungsvariablen (siehe GitHub Actions Workflow) -
# NICHT direkt hier eintragen, damit sie nicht im Code landen.
DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "")
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")


def fetch_page(url: str) -> str:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0 Safari/537.36"
        )
    }
    resp = requests.get(url, headers=headers, timeout=15)
    resp.raise_for_status()
    return resp.text.lower()


def is_out_of_stock(html: str) -> bool:
    return any(pattern in html for pattern in OUT_OF_STOCK_PATTERNS)


def read_last_state() -> str:
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    return "unknown"


def write_last_state(state: str) -> None:
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        f.write(state)


def notify_discord(message: str) -> None:
    if not DISCORD_WEBHOOK_URL:
        return
    try:
        requests.post(DISCORD_WEBHOOK_URL, json={"content": message}, timeout=10)
    except requests.RequestException as exc:
        print(f"Discord-Benachrichtigung fehlgeschlagen: {exc}", file=sys.stderr)


def notify_telegram(message: str) -> None:
    if not (TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID):
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    try:
        requests.post(
            url, json={"chat_id": TELEGRAM_CHAT_ID, "text": message}, timeout=10
        )
    except requests.RequestException as exc:
        print(f"Telegram-Benachrichtigung fehlgeschlagen: {exc}", file=sys.stderr)


def main() -> None:
    if "PASTE-DIE-ECHTE-PRODUKTSEITE-HIER-EIN" in PRODUCT_URL:
        print(
            "FEHLER: Bitte zuerst PRODUCT_URL in restock_checker.py durch die "
            "echte Produktseite ersetzen.",
            file=sys.stderr,
        )
        sys.exit(1)

    html = fetch_page(PRODUCT_URL)
    currently_out = is_out_of_stock(html)
    current_state = "out" if currently_out else "in"
    last_state = read_last_state()

    print(f"Letzter bekannter Status: {last_state} | Aktueller Status: {current_state}")

    if current_state == "in" and last_state != "in":
        message = (
            "🚨 WIEDER VERFÜGBAR (mutmaßlich) — sofort prüfen und bestellen:\n"
            f"{PRODUCT_URL}"
        )
        notify_discord(message)
        notify_telegram(message)
        print("Statuswechsel erkannt -> Benachrichtigung gesendet.")

    write_last_state(current_state)


if __name__ == "__main__":
    main()
