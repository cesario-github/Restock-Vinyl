# GTA 6 Vinyl Restock-Checker (kostenlos, per Discord/Telegram)

Prüft alle 5 Minuten automatisch eine Produktseite und schickt dir sofort
eine Discord- und/oder Telegram-Nachricht, sobald sich der Status von
"ausverkauft" auf "verfügbar" ändert. Läuft komplett kostenlos über
GitHub Actions – unabhängig von deinem Handy.

## Einmalige Einrichtung (ca. 10–15 Minuten)

### 1. GitHub-Repository anlegen
- Kostenloses Konto auf github.com erstellen (falls noch nicht vorhanden)
- Neues **privates** Repository anlegen (z.B. `gta6-restock`)
- Diese drei Dateien in genau dieser Ordnerstruktur hochladen:
  ```
  restock_checker.py
  .github/workflows/check_restock.yml
  ```
  (Über "Add file" → "Upload files" im Browser geht das ohne Kommandozeile.)

### 2. Discord-Webhook erstellen
- In deinem eigenen Discord-Server: Kanal auswählen → Zahnrad/Kanal
  bearbeiten → **Integrationen** → **Webhooks** → **Neuer Webhook**
- Webhook-URL kopieren

### 3. Webhook-URL sicher in GitHub hinterlegen
- Im Repository: **Settings** → **Secrets and variables** → **Actions**
  → **New repository secret**
- Name: `DISCORD_WEBHOOK_URL`
- Wert: die kopierte Webhook-URL
- Speichern

### 4. (Optional, aber empfohlen) Telegram als zweiten Kanal einrichten
Telegram-Push gilt als sehr zuverlässig und ist in 2 Minuten eingerichtet:
- In Telegram den Bot **@BotFather** öffnen → `/newbot` → Namen vergeben
  → du bekommst einen **Bot-Token**
- Deinen eigenen Chat mit dem neuen Bot starten (einmal "Start" klicken)
- Deine **Chat-ID** herausfinden, z.B. über den Bot **@userinfobot**
- Beide Werte als weitere Secrets in GitHub anlegen:
  `TELEGRAM_BOT_TOKEN` und `TELEGRAM_CHAT_ID`

### 5. Produktseite eintragen
- In `restock_checker.py` die Zeile `PRODUCT_URL = "..."` durch die
  echte Adresse der Limited-Edition-Produktseite ersetzen
  (am besten direkt aus der Adresszeile kopieren, wenn du die Seite
  selbst aufrufst – nicht den Kurzlink aus einem Tweet)
- Änderung committen

### 6. Testen
- Im Repository auf den Tab **Actions** gehen
- Workflow "GTA6 Vinyl Restock Checker" auswählen → **Run workflow**
  (manuell auslösen)
- Prüfen, ob der Lauf grün durchläuft und ob (bei bereits verfügbarem
  Testartikel) eine Nachricht in Discord/Telegram ankommt

Danach läuft der Check automatisch alle 5 Minuten, ganz ohne dein Zutun.

## Wichtige Einschränkung

Manche Shops laden den Lagerbestand per JavaScript nach, nachdem die
Seite schon geladen ist (moderne React/Next.js-Shops machen das oft).
Ein einfacher Seitenabruf wie in diesem Skript sieht dann u.U. nicht den
tatsächlichen Status. Falls der Checker im Test keine zuverlässigen
Ergebnisse liefert, ist das der wahrscheinlichste Grund – dann bräuchte
es zusätzlich einen "echten" Browser (z.B. über Playwright), was etwas
aufwändiger einzurichten ist.

## Kostenlose Alternative ohne eigenen Code

Falls dir das Einrichten über GitHub zu viel ist: Dienste wie
**Distill.io** oder **Visualping** überwachen Webseiten ebenfalls
kostenlos auf Änderungen und können per E-Mail (im Gratis-Tarif meist
zuverlässiger als sofortige Discord-Pushes) benachrichtigen. Einfacher
einzurichten, aber typischerweise etwas langsamer als eine eigene
5-Minuten-Prüfung.
